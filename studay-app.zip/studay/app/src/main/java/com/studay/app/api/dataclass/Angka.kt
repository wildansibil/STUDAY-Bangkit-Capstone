package com.studay.app.api.dataclass

data class Angka(
    val id: Int,
    val formula: String,
    val description: String
)
