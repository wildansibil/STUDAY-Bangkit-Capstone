package com.studay.app

import android.graphics.Paint
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.studay.app.databinding.ActivityMenulisBinding

class MenulisActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMenulisBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMenulisBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Contoh data huruf
        val hurufList = listOf(
            Huruf("A", R.drawable.ic_sound),
            Huruf("B", R.drawable.ic_sound),
            Huruf("C", R.drawable.ic_sound)
        )

        setupRecyclerView(hurufList)
        setupCvGambar()
    }

    private fun setupRecyclerView(hurufList: List<Huruf>) {
        binding.rvAbjad.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.rvAbjad.adapter = MenulisAdapter(hurufList) { huruf ->
            // Handle item yang diklik
            Toast.makeText(this, "Huruf Dipilih: ${huruf.huruf}", Toast.LENGTH_SHORT).show()
            // Tambahkan logika menggambar berdasarkan huruf yang dipilih
        }
    }

    private fun setupCvGambar() {
        // Tidak perlu logika tambahan di sini kecuali untuk fitur reset atau undo
        binding.cvGambar.setOnClickListener {
            Toast.makeText(this, "Mulai menggambar", Toast.LENGTH_SHORT).show()
        }
    }

}
