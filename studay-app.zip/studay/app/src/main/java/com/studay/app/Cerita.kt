package com.studay.app

data class Cerita(
    val judul: String,
    val deskripsi: String,
    val gambar: Int // Resource ID untuk gambar
)