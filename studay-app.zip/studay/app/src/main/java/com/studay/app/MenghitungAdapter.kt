package com.studay.app

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class MenghitungAdapter(private val hurufList: List<Huruf>, private val onClick: (Huruf) -> Unit) :
    RecyclerView.Adapter<MenghitungAdapter.MenghitungViewHolder>() {

    inner class MenghitungViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvHuruf: TextView = itemView.findViewById(R.id.tvHuruf)
        val soundIcon: ImageView = itemView.findViewById(R.id.ivSound)

        fun bind(huruf: Huruf) {
            tvHuruf.text = huruf.huruf
            soundIcon.setImageResource(huruf.soundIcon)
            itemView.setOnClickListener { onClick(huruf) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MenghitungViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_huruf, parent, false)
        return MenghitungViewHolder(view)
    }

    override fun onBindViewHolder(holder: MenghitungViewHolder, position: Int) {
        holder.bind(hurufList[position])
    }

    override fun getItemCount(): Int = hurufList.size
}