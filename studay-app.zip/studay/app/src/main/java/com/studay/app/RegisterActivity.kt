package com.studay.app

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.studay.app.LoginActivity

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val nameInput = findViewById<EditText>(R.id.input_login_Nama)
        val emailInput = findViewById<EditText>(R.id.input_login_Email)
        val passwordInput = findViewById<EditText>(R.id.input_login_password)
        val confirmPasswordInput = findViewById<EditText>(R.id.input_login_password2)
        val registerButton = findViewById<Button>(R.id.btnRegister)

        registerButton.setOnClickListener {
            val name = nameInput.text.toString().trim()
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString().trim()
            val confirmPassword = confirmPasswordInput.text.toString().trim()

            // Validasi input
            when {
                name.isEmpty() -> showToast("Nama pengguna wajib diisi")
                email.isEmpty() -> showToast("Email wajib diisi")
                password.isEmpty() -> showToast("Password wajib diisi")
                confirmPassword.isEmpty() -> showToast("Konfirmasi password wajib diisi")
                password != confirmPassword -> showToast("Password tidak cocok")
                else -> {
                    // Jika validasi berhasil, navigasi ke LoginActivity
                    val intent = Intent(this, LoginActivity::class.java)
                    startActivity(intent)
                    finish() // Menutup RegisterActivity agar pengguna tidak kembali
                }
            }
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
