package com.studay.app

data class Huruf(
    val huruf: String,
    val soundIcon: Int // ID drawable untuk ikon suara
)
