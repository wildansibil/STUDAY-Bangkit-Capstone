package com.studay.app.api.dataclass

data class User(
    val nama: String,
    val email: String,
    val password: String
)
