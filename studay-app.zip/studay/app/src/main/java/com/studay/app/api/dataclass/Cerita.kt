package com.studay.app.api.dataclass

data class Cerita(
    val judul: String,
    val deskripsi: String,
    val gambar: String // Resource ID untuk gambar
)