package com.studay.app.api.dataclass

data class SukuKata(
    val sukukata: String,
    val suara: String // URL atau path ke file suara
)

