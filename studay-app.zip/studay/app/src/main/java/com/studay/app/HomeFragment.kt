package com.studay.app

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.studay.app.databinding.FragmentHomeBinding
import androidx.navigation.fragment.findNavController

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)

        binding.cvMembaca.setOnClickListener {
            val intent = Intent(requireContext(), MembacaActivity::class.java)
            startActivity(intent)
        }

        binding.cvMenulis.setOnClickListener {
            val intent = Intent(requireContext(), MenulisActivity::class.java)
            startActivity(intent)
        }

        binding.cvMenghitung.setOnClickListener {
            val intent = Intent(requireContext(), MenghitungActivity::class.java)
            startActivity(intent)
        }


        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
