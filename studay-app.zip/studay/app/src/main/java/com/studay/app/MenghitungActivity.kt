package com.studay.app

import android.os.Bundle
import android.view.View
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MenghitungActivity : AppCompatActivity() {

    private lateinit var rvAbjad: RecyclerView
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menghitung) // Menggunakan layout yang sama

        rvAbjad = findViewById(R.id.rvAngka)
        progressBar = findViewById(R.id.loadingCerita)

        setupRecyclerView()
    }

    private fun setupRecyclerView() {
        progressBar.visibility = View.VISIBLE

        // Contoh data dummy
        val hurufList = listOf(
            Huruf("A", R.drawable.ic_sound),
            Huruf("B", R.drawable.ic_sound),
            Huruf("C", R.drawable.ic_sound)
        )

        rvAbjad.layoutManager = GridLayoutManager(this, 2) // 2 kolom
        rvAbjad.adapter = MenghitungAdapter(hurufList) { huruf ->
            // Handle klik pada item
            Toast.makeText(this, "Huruf: ${huruf.huruf}", Toast.LENGTH_SHORT).show()
        }

        progressBar.visibility = View.GONE
    }
}
