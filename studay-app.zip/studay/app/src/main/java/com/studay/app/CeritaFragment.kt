package com.studay.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class CeritaFragment : Fragment() {

    private lateinit var rvCerita: RecyclerView
    private lateinit var progressBar: ProgressBar

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_cerita, container, false)
        rvCerita = view.findViewById(R.id.rvCerita)
        progressBar = view.findViewById(R.id.loadingCerita)

        setupRecyclerView()
        return view
    }

    private fun setupRecyclerView() {
        progressBar.visibility = View.VISIBLE

        // Contoh data cerita
        val ceritaList = listOf(
            Cerita("Judul 1", "Deskripsi cerita 1", R.drawable.ic_image),
            Cerita("Judul 2", "Deskripsi cerita 2", R.drawable.ic_image),
            Cerita("Judul 3", "Deskripsi cerita 3", R.drawable.ic_image)
        )

        rvCerita.layoutManager = LinearLayoutManager(requireContext())
        rvCerita.adapter = CeritaAdapter(ceritaList) { cerita ->
            // Handle klik item
            Toast.makeText(requireContext(), "Dipilih: ${cerita.judul}", Toast.LENGTH_SHORT).show()
        }

        progressBar.visibility = View.GONE
    }
}
