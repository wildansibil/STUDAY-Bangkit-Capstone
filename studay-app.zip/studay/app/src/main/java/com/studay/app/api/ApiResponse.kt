package com.studay.app.api

data class ApiResponse(
    val error: Boolean,
    val message: String
)
