package com.studay.app.api.dataclass

data class Huruf(
    val huruf: Char,
    val suara: String // URL atau path ke file suara
)

